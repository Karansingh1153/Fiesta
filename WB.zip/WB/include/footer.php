<!DOCTYPE html>
<html lang="en">

<body>
    <div class="row w-100 mx-auto">
        <div class="col-12 col-md-12 col-lg-12 mx-auto d-flex justify-content-center align-items-center header-footer">
            <footer class="container mx-auto">
                <div class="container-fluid">
                <div class="footer">
                    <div class="copy">
                            <p>Copyright &#169; 2023 Fiesta. All rights reserved.</p>
                        </div>
                        <div class="social">
                            <a href="#" class="social-icon"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="social-icon"><i class="bi bi-instagram"></i></a>
                            <a href="#" class="social-icon"><i class="bi bi-twitter"></i></a>
                            <a href="#" class="social-icon"><i class="bi bi-pinterest"></i></a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>

</html>